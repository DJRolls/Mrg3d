```markdown
# MRG3D — 3D Print Prep (client-only)

A small static web tool to prepare 3D models for printing. Load a model (GLB/GLTF/STL/OBJ), place/scale/rotate it on a visible print bed, and export an STL ready for slicing.

Features
- Loads .glb/.gltf/.stl/.obj via drag & drop or file picker.
- Orbit controls, bed grid visualization, fit & center tools.
- Uniform scale, rotate Y, translate (X/Y/Z) sliders (translation shown in mm).
- Export transformed STL (download).
- Screenshot of current view.

How to run locally
1. Download the files (index.html, styles.css, script.js).
2. Open `index.html` in a modern browser (Chrome/Edge/Firefox). No server required.
   - Note: some browsers restrict local file access for linked module imports. If you see module import errors, serve the folder with a simple static server:
     - Python 3: `python -m http.server 8000`
     - Then open http://localhost:8000/

Deploy to GitHub Pages (www.mrg3d.net)
1. Create the repo `DJRolls/mrg3d` on GitHub (or run the git commands below).
2. Add all files and push to `main` branch.
3. Create a DNS CNAME record at your domain registrar:
   - Host: `www`
   - Type: `CNAME`
   - Value: `DJRolls.github.io`
4. Add the provided `CNAME` file to the repo root (it contains `www.mrg3d.net`).
5. In GitHub → Repository → Settings → Pages, set Source to: `main` branch / (root).
6. Wait for GitHub to provision TLS. When ready, enable "Enforce HTTPS".
7. (Optional) Add a redirect from the apex `mrg3d.net` to `https://www.mrg3d.net` via your registrar.

Notes & tips
- Exported STL uses the current transforms and assumes UI translation values are in millimeters (converted to meters on export). Confirm units in your slicer (scale may be needed).
- If your model uses a different unit convention, adjust scale before exporting.
- If using Cloudflare, set the www CNAME to DNS-only (gray cloud) while GitHub issues the TLS certificate.
- For advanced operations (hollowing, boolean ops, slicing) consider a server-side tool or local slicer.

Troubleshooting
- If the site shows a blank page: ensure your browser supports ES modules or run a local static server.
- If HTTPS fails after setting CNAME: confirm the CNAME points to `DJRolls.github.io` and you haven't enabled Cloudflare proxying.
- If exported STL seems scaled incorrectly: check the scale UI, and the slicer import units. Model units vary by authoring software.

If you want improvements:
- Add per-axis scale, rotation for all axes, or numeric inputs.
- Add STL repair/boolean/hollow features via a WASM library.
- Add an option to upload exported STL to an OctoPrint instance (requires API key).
- Add an environment map and better materials for preview.

Enjoy — drop a model and prepare it for printing!
```