// MRG3D — 3D Print Prep (browser-only)
// Requires modern browser with module support

import * as THREE from 'https://unpkg.com/three@0.155.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.155.0/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.155.0/examples/jsm/loaders/GLTFLoader.js';
import { OBJLoader } from 'https://unpkg.com/three@0.155.0/examples/jsm/loaders/OBJLoader.js';
import { STLLoader } from 'https://unpkg.com/three@0.155.0/examples/jsm/loaders/STLLoader.js';
import { STLExporter } from 'https://unpkg.com/three@0.155.0/examples/jsm/exporters/STLExporter.js';
import { Box3, Vector3 } from 'https://unpkg.com/three@0.155.0/build/three.module.js';

const canvas = document.getElementById('three-canvas');
const dropOverlay = document.getElementById('dropOverlay');
const fileInput = document.getElementById('fileInput');
const info = document.getElementById('info');

const fitBtn = document.getElementById('fitBtn');
const centerBtn = document.getElementById('centerBtn');
const resetBtn = document.getElementById('resetBtn');

const scaleInput = document.getElementById('scale');
const scaleVal = document.getElementById('scaleVal');
const rotY = document.getElementById('rotY');
const rotYVal = document.getElementById('rotYVal');

const tx = document.getElementById('tx'), ty = document.getElementById('ty'), tz = document.getElementById('tz');
const txVal = document.getElementById('txVal'), tyVal = document.getElementById('tyVal'), tzVal = document.getElementById('tzVal');

const bedW = document.getElementById('bedW'), bedD = document.getElementById('bedD'), bedH = document.getElementById('bedH');

const exportBtn = document.getElementById('exportBtn');
const screenshotBtn = document.getElementById('screenshotBtn');

let renderer, scene, camera, controls;
let currentModel = null;
let modelURL = null;
let bedMesh = null;

init();
animate();

function init(){
  // Renderer
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  resize();
  window.addEventListener('resize', () => { resize(); camera.aspect = canvas.clientWidth / canvas.clientHeight; camera.updateProjectionMatrix(); });

  // Scene & Camera
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x071027);

  camera = new THREE.PerspectiveCamera(50, canvas.clientWidth / canvas.clientHeight, 0.01, 1000);
  camera.position.set(2, 2, 2);

  // Controls
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;

  // Lights
  scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 0.9));
  const dir = new THREE.DirectionalLight(0xffffff, 1.0);
  dir.position.set(3, 10, 5);
  scene.add(dir);

  // Grid and initial bed
  drawBed();

  // Event hooks
  fileInput.addEventListener('change', (e) => { if (e.target.files && e.target.files[0]) loadFile(e.target.files[0]); e.target.value = ''; });

  ['dragenter','dragover'].forEach(ev => {
    canvas.addEventListener(ev, (e) => { e.preventDefault(); dropOverlay.style.display = 'flex'; }, false);
  });
  ['dragleave','drop'].forEach(ev => {
    canvas.addEventListener(ev, (e) => { e.preventDefault(); dropOverlay.style.display = 'none'; }, false);
  });

  canvas.addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (f) loadFile(f);
  });

  fitBtn.addEventListener('click', () => fitModel());
  centerBtn.addEventListener('click', () => centerOnBed());
  resetBtn.addEventListener('click', () => resetScene());
  exportBtn.addEventListener('click', () => exportSTL());
  screenshotBtn.addEventListener('click', () => downloadScreenshot());

  // Transform UI
  scaleInput.addEventListener('input', () => { scaleVal.textContent = parseFloat(scaleInput.value).toFixed(2); applyTransformUI(); });
  rotY.addEventListener('input', () => { rotYVal.textContent = `${rotY.value}°`; applyTransformUI(); });
  tx.addEventListener('input', () => { txVal.textContent = tx.value; applyTransformUI(); });
  ty.addEventListener('input', () => { tyVal.textContent = ty.value; applyTransformUI(); });
  tz.addEventListener('input', () => { tzVal.textContent = tz.value; applyTransformUI(); });

  bedW.addEventListener('change', drawBed);
  bedD.addEventListener('change', drawBed);
  bedH.addEventListener('change', drawBed);

  updateInfo('No model loaded.');
}

function resize(){
  const w = canvas.clientWidth || canvas.offsetWidth || 800;
  const h = canvas.clientHeight || canvas.offsetHeight || 600;
  renderer.setSize(w, h, false);
}

function animate(){
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}

// Loaders
const gltfLoader = new GLTFLoader();
const objLoader = new OBJLoader();
const stlLoader = new STLLoader();

async function loadFile(file){
  const name = file.name || 'model';
  const ext = name.split('.').pop().toLowerCase();
  updateInfo(`Loading ${name}...`);
  try {
    if (modelURL) { URL.revokeObjectURL(modelURL); modelURL = null; }
    modelURL = URL.createObjectURL(file);

    if (ext === 'glb' || ext === 'gltf') {
      gltfLoader.load(modelURL, (gltf) => addModel(gltf.scene || gltf.scenes[0], name), undefined, (err) => { console.error(err); updateInfo('Failed to load GLTF/GLB.'); });
    } else if (ext === 'stl') {
      stlLoader.load(modelURL, (geometry) => {
        const mat = new THREE.MeshStandardMaterial({ color: 0x9fbff3, metalness: 0.1, roughness: 0.6 });
        const mesh = new THREE.Mesh(geometry, mat);
        addModel(mesh, name);
      }, undefined, (err) => { console.error(err); updateInfo('Failed to load STL.'); });
    } else if (ext === 'obj') {
      objLoader.load(modelURL, (obj) => addModel(obj, name), undefined, (err) => { console.error(err); updateInfo('Failed to load OBJ.'); });
    } else {
      updateInfo('Unsupported file type. Supported: glb/gltf/stl/obj');
    }
  } catch (err) {
    console.error(err);
    updateInfo('Error while loading file.');
  }
}

function addModel(object, name){
  if (currentModel) scene.remove(currentModel);
  // Ensure a container group so we can apply transforms easily
  const group = new THREE.Group();
  group.name = 'modelRoot';
  group.add(object);
  // Normalize metrics
  object.traverse((c) => { if (c.isMesh) { c.castShadow=true; c.receiveShadow=true; if (Array.isArray(c.material)) c.material.forEach(m => m.side = THREE.DoubleSide); else c.material.side = THREE.DoubleSide; } });
  currentModel = group;
  scene.add(currentModel);
  // Reset transform UI
  scaleInput.value = 1; scaleVal.textContent = '1.00';
  rotY.value = 0; rotYVal.textContent = '0°';
  tx.value = ty.value = tz.value = 0; txVal.textContent = tyVal.textContent = tzVal.textContent = '0';
  fitModel();
  updateInfo(`Loaded: ${name}`);
}

function fitModel(){
  if (!currentModel) return updateInfo('No model to fit.');
  const box = new Box3().setFromObject(currentModel);
  const center = new Vector3(); box.getCenter(center);
  const size = new Vector3(); box.getSize(size);
  const maxDim = Math.max(size.x, size.y, size.z);
  const fov = camera.fov * (Math.PI / 180);
  let distance = Math.abs(maxDim / 2 / Math.tan(fov / 2));
  distance *= 1.6;
  const dir = new Vector3(1, 1, 1).normalize();
  camera.position.copy(center).add(dir.multiplyScalar(distance));
  camera.near = Math.max(0.001, distance / 1000);
  camera.far = distance * 1000;
  camera.updateProjectionMatrix();
  controls.target.copy(center);
  controls.update();
  updateInfo(`Model fit. Size: ${ (size.x).toFixed(3) } × ${ (size.y).toFixed(3) } × ${ (size.z).toFixed(3) }`);
}

function centerOnBed(){
  if (!currentModel) return updateInfo('No model loaded.');
  // compute current model bounding box center and move it to bed center (x,z) and set its min Y to bed plane (y=0)
  const box = new Box3().setFromObject(currentModel);
  const size = new Vector3(); box.getSize(size);
  const min = box.min.clone();
  const max = box.max.clone();
  const center = new Vector3(); box.getCenter(center);

  // Desired bed center (0,0,0) as we draw bed at y=0 with center at (0,0)
  // Apply translations from UI after centering
  currentModel.position.x += -center.x;
  currentModel.position.z += -center.z;
  // Move so min.y sits at 0:
  currentModel.position.y += -min.y;
  applyTransformUI();
  updateInfo('Centered on bed.');
}

function applyTransformUI(){
  if (!currentModel) return;
  const s = parseFloat(scaleInput.value) || 1;
  const ry = parseFloat(rotY.value) * (Math.PI/180);
  const txv = parseFloat(tx.value) || 0;
  const tyv = parseFloat(ty.value) || 0;
  const tzv = parseFloat(tz.value) || 0;
  // We treat the UI translate as millimeter offsets — but rely on the model units as-is.
  currentModel.scale.setScalar(s);
  currentModel.rotation.set(0, ry, 0);
  currentModel.position.set(txv/1000, tyv/1000, tzv/1000); // convert mm -> meters (common assumption)
  currentModel.updateMatrixWorld(true);
}

function resetScene(){
  if (currentModel) { scene.remove(currentModel); currentModel = null; }
  if (modelURL) { URL.revokeObjectURL(modelURL); modelURL = null; }
  updateInfo('Scene cleared.');
}

function drawBed(){
  // Remove existing bed
  if (bedMesh) scene.remove(bedMesh);
  const w = parseFloat(bedW.value) || 200;
  const d = parseFloat(bedD.value) || 200;
  const h = parseFloat(bedH.value) || 200;
  // Bed plane at y=0 centered at origin. Units: mm -> meters
  const gw = w/1000, gd = d/1000;
  const grid = new THREE.GridHelper(Math.max(gw, gd), 10, 0x2a6bd6, 0x12233a);
  grid.material.opacity = 0.1;
  grid.material.transparent = true;
  grid.rotation.x = Math.PI/2 * 0; // keep horizontal grid aligned with ground
  grid.position.y = 0;
  // bed border box
  const geom = new THREE.BoxGeometry(gw, 0.001, gd);
  const mat = new THREE.MeshBasicMaterial({ color: 0x133447, transparent: true, opacity: 0.4 });
  bedMesh = new THREE.Group();
  const plane = new THREE.Mesh(geom, mat);
  plane.position.y = 0;
  bedMesh.add(plane);
  bedMesh.add(grid);
  scene.add(bedMesh);
}

function exportSTL(){
  if (!currentModel) return updateInfo('No model to export.');
  // Apply UI transforms (scale/rotate/translate)
  applyTransformUI();
  // Ensure world matrices updated
  currentModel.updateMatrixWorld(true);
  // Use STLExporter to export the current model (as a mesh group)
  const exporter = new STLExporter();
  // We export in binary string by default (as legacy: exporter.parse returns string)
  const stlString = exporter.parse(currentModel);
  const blob = new Blob([stlString], { type: 'model/stl' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'model_export.stl';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  updateInfo('STL exported (download started). Note: check units/scale in your slicer before printing.');
}

function downloadScreenshot(){
  try {
    renderer.render(scene, camera);
    const dataURL = renderer.domElement.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataURL;
    a.download = 'mrg3d_screenshot.png';
    document.body.appendChild(a);
    a.click();
    a.remove();
    updateInfo('Screenshot downloaded.');
  } catch (err) {
    console.error(err);
    updateInfo('Screenshot failed.');
  }
}

function updateInfo(text){ info.textContent = text || ''; }