// script.js — mrg3d 3D Print Prep (module)
import * as THREE from 'https://unpkg.com/three@0.155.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.155.0/examples/jsm/controls/OrbitControls.js';
import { TransformControls } from 'https://unpkg.com/three@0.155.0/examples/jsm/controls/TransformControls.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.155.0/examples/jsm/loaders/GLTFLoader.js';
import { OBJLoader } from 'https://unpkg.com/three@0.155.0/examples/jsm/loaders/OBJLoader.js';
import { STLLoader } from 'https://unpkg.com/three@0.155.0/examples/jsm/loaders/STLLoader.js';
import { STLExporter } from 'https://unpkg.com/three@0.155.0/examples/jsm/exporters/STLExporter.js';
import { Box3, Vector3, MeshStandardMaterial } from 'https://unpkg.com/three@0.155.0/build/three.module.js';

const canvas = document.getElementById('three-canvas');
const dropOverlay = document.getElementById('dropOverlay');
const fileInput = document.getElementById('fileInput');
const fitBtn = document.getElementById('fitBtn');
const centerBtn = document.getElementById('centerBtn');
const resetBtn = document.getElementById('resetBtn');
const exportBtn = document.getElementById('exportBtn');
const infoEl = document.getElementById('info');

const bedWEl = document.getElementById('bedW');
const bedDEl = document.getElementById('bedD');
const bedHEl = document.getElementById('bedH');
const unitsEl = document.getElementById('units');
const transformModeEl = document.getElementById('transformMode');
const snapToggleEl = document.getElementById('snapToggle');

let renderer, scene, camera, controls, transformControls;
let currentModel = null;
let modelUrl = null;
let exporter = new STLExporter();

init();
animate();

function init(){
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputEncoding = THREE.sRGBEncoding;
  resize();

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x071027);

  camera = new THREE.PerspectiveCamera(50, canvas.clientWidth / canvas.clientHeight, 0.01, 1000);
  camera.position.set(2, 2, 2);

  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;

  // lights
  const hemi = new THREE.HemisphereLight(0xffffff, 0x333333, 0.9);
  scene.add(hemi);
  const dir = new THREE.DirectionalLight(0xffffff, 1.0);
  dir.position.set(3, 10, 5);
  scene.add(dir);

  // grid and axes
  const grid = new THREE.GridHelper(220, 22, 0x2a6bd6, 0x12233a);
  grid.material.opacity = 0.06; grid.material.transparent = true;
  scene.add(grid);

  transformControls = new TransformControls(camera, renderer.domElement);
  transformControls.addEventListener('dragging-changed', (evt) => {
    controls.enabled = !evt.value;
  });
  scene.add(transformControls);

  window.addEventListener('resize', () => {
    resize();
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
  });

  // file input + drag/drop
  fileInput.addEventListener('change', e => {
    if (e.target.files && e.target.files[0]) loadFile(e.target.files[0]);
    e.target.value = '';
  });

  ['dragenter','dragover'].forEach(evt => {
    canvas.addEventListener(evt, e => { e.preventDefault(); dropOverlay.style.display = 'flex'; }, false);
  });
  ['dragleave','drop'].forEach(evt => {
    canvas.addEventListener(evt, e => { e.preventDefault(); dropOverlay.style.display = 'none'; }, false);
  });
  canvas.addEventListener('drop', e => {
    const f = e.dataTransfer.files[0];
    if (f) loadFile(f);
  });

  // buttons
  fitBtn.addEventListener('click', () => fitToBed());
  centerBtn.addEventListener('click', () => centerModel());
  resetBtn.addEventListener('click', () => resetScene());
  exportBtn.addEventListener('click', () => exportSTL());

  transformModeEl.addEventListener('change', () => {
    transformControls.setMode(transformModeEl.value);
  });

  snapToggleEl.addEventListener('change', () => {
    const useSnap = snapToggleEl.checked;
    if (useSnap) {
      transformControls.setTranslationSnap(1);
      transformControls.setScaleSnap(0.01);
      transformControls.setRotationSnap(THREE.MathUtils.degToRad(15));
    } else {
      transformControls.setTranslationSnap(null);
      transformControls.setScaleSnap(null);
      transformControls.setRotationSnap(null);
    }
  });

  updateInfo('No model loaded.');
}

function resize(){
  const w = canvas.clientWidth || canvas.offsetWidth || 800;
  const h = canvas.clientHeight || canvas.offsetHeight || 600;
  renderer.setSize(w, h, false);
}

function animate(){
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
}

const gltfLoader = new GLTFLoader();
const objLoader = new OBJLoader();
const stlLoader = new STLLoader();

async function loadFile(file){
  const name = file.name || 'model';
  const ext = name.split('.').pop().toLowerCase();
  updateInfo(`Loading ${name}...`);
  try {
    if (modelUrl) { URL.revokeObjectURL(modelUrl); modelUrl = null; }
    modelUrl = URL.createObjectURL(file);

    if (ext === 'glb' || ext === 'gltf') {
      gltfLoader.load(modelUrl, gltf => {
        addModel(gltf.scene || gltf.scenes[0], name);
      }, undefined, err => {
        console.error(err); updateInfo('Failed to load GLTF/GLB.');
      });
    } else if (ext === 'stl') {
      stlLoader.load(modelUrl, geom => {
        const mat = new MeshStandardMaterial({ color: 0x9fbff3, metalness: 0.05, roughness: 0.6 });
        const mesh = new THREE.Mesh(geom, mat);
        addModel(mesh, name);
      }, undefined, err => {
        console.error(err); updateInfo('Failed to load STL.');
      });
    } else if (ext === 'obj') {
      objLoader.load(modelUrl, obj => {
        addModel(obj, name);
      }, undefined, err => {
        console.error(err); updateInfo('Failed to load OBJ.');
      });
    } else {
      updateInfo('Unsupported file type. Use .glb/.gltf/.stl/.obj');
      URL.revokeObjectURL(modelUrl); modelUrl = null;
    }
  } catch (err) {
    console.error(err);
    updateInfo('Error while loading file.');
  }
}

function addModel(object, name){
  if (currentModel) scene.remove(currentModel);
  // ensure material on STL raw geometries
  object.traverse(c => {
    if (c.isMesh) {
      if (!c.material) c.material = new MeshStandardMaterial({ color: 0x9fbff3 });
      c.castShadow = true; c.receiveShadow = true;
      c.geometry && c.geometry.computeVertexNormals();
    }
  });

  // normalize scale if extremely large or small
  const box = new Box3().setFromObject(object);
  const size = new Vector3();
  box.getSize(size);
  const maxDim = Math.max(size.x, size.y, size.z);
  if (maxDim > 0) {
    let scale = 1;
    if (maxDim > 1000) scale = 0.001;
    else if (maxDim < 0.01) scale = 1000;
    object.scale.multiplyScalar(scale);
  }

  currentModel = object;
  scene.add(currentModel);

  // attach transform controls to model
  transformControls.detach();
  transformControls.attach(currentModel);
  updateInfo(`Loaded: ${name}`);
  fitToBed();
}

function fitToBed(){
  if (!currentModel) return updateInfo('No model loaded.');
  // compute model bounding box in object space
  const box = new Box3().setFromObject(currentModel);
  const size = new Vector3(); box.getSize(size);

  // bed dimensions in mm
  const bedW = parseFloat(bedWEl.value) || 220;
  const bedD = parseFloat(bedDEl.value) || 220;
  const bedH = parseFloat(bedHEl.value) || 220;

  // scene units -> mm mapping (we assume 1 unit == 1 mm by default)
  // if user chooses cm, convert bed dims to mm then treat same
  const units = unitsEl.value;
  const bedWmm = units === 'cm' ? bedW * 10 : bedW;
  const bedDmm = units === 'cm' ? bedD * 10 : bedD;
  const bedHmm = units === 'cm' ? bedH * 10 : bedH;

  // current model size is in scene units; we treat scene unit = mm by default
  const maxModelDim = Math.max(size.x, size.y, size.z);
  const maxBedDim = Math.max(bedWmm, bedDmm, bedHmm);
  if (maxModelDim <= 0) return updateInfo('Model has no size.');

  const scale = Math.min(bedWmm / size.x, bedDmm / size.y, bedHmm / size.z);
  if (!isFinite(scale) || scale <= 0) return updateInfo('Could not compute scale.');

  currentModel.scale.multiplyScalar(scale * 0.98); // slight padding
  // re-center so base sits on bed plane (y=0)
  centerModelToBed();

  updateInfo(`Model scaled to fit bed (scale ×${(scale*0.98).toFixed(3)})`);
}

function centerModelToBed(){
  if (!currentModel) return;
  const box = new Box3().setFromObject(currentModel);
  const center = new Vector3(); box.getCenter(center);
 
