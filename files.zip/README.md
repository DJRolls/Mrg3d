# Random Joke Generator

Simple static site that fetches a random joke from an external API and displays it.

Features
- Fetches from Official Joke API (primary) and falls back to icanhazdadjoke.
- Loading and error states.
- Copy to clipboard and native share support.
- Small and dependency-free.

How to run
1. Clone or download the files (index.html, styles.css, script.js).
2. Open `index.html` in a browser (no server required).
   - For best results use a modern browser with fetch and clipboard APIs.

Deploy to GitHub Pages
1. Create a new repository (for example `DJRolls/random-jokes`) and push these files to the repo's `main` branch.
2. In the repository settings → Pages, set the site source to `main` branch `/ (root)`.
3. The site will be available at `https://<your-username>.github.io/<repo>/` (or `https://<your-username>.github.io/` if repo named `<your-username>.github.io`).
4. If using a custom domain, follow GitHub Pages DNS instructions and add a `CNAME` in Settings (or create a `CNAME` file with your domain).

APIs used
- Official Joke API: https://official-joke-api.appspot.com/random_joke
- icanhazdadjoke (fallback): https://icanhazdadjoke.com/

Notes
- These public APIs may have rate limits or availability differences. For production use consider adding server-side caching or using a paid API or your own joke dataset.
- If a CORS or certificate issue occurs when deployed behind a proxy (Cloudflare etc.), ensure you are not interfering with direct requests to the APIs.

Enjoy the jokes! If you'd like, I can:
- Add animations or a "Laugh meter".
- Make this a tiny React/Vue app and configure a GitHub Actions workflow to build/deploy.
- Add unit tests for the fetch logic.