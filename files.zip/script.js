const newJokeBtn = document.getElementById('newJokeBtn');
const copyBtn = document.getElementById('copyBtn');
const shareBtn = document.getElementById('shareBtn');

const loadingEl = document.getElementById('loading');
const setupEl = document.getElementById('setup');
const punchlineEl = document.getElementById('punchline');
const errorEl = document.getElementById('error');

async function fetchFromOfficial() {
  const res = await fetch('https://official-joke-api.appspot.com/random_joke', {cache: 'no-store'});
  if (!res.ok) throw new Error('Official API error: ' + res.status);
  return res.json(); // {id, type, setup, punchline}
}

async function fetchFromIcanhaz() {
  const res = await fetch('https://icanhazdadjoke.com/', {
    headers: { Accept: 'application/json' },
    cache: 'no-store'
  });
  if (!res.ok) throw new Error('icanhaz error: ' + res.status);
  return res.json(); // {id, joke}
}

function setLoading(on = true) {
  loadingEl.style.display = on ? 'block' : 'none';
  setupEl.textContent = on ? '' : setupEl.textContent;
  punchlineEl.textContent = on ? '' : punchlineEl.textContent;
  errorEl.hidden = true;
  copyBtn.disabled = on;
  shareBtn.disabled = on;
}

function displayJoke(setup, punchline = '') {
  loadingEl.style.display = 'none';
  setupEl.textContent = setup || '';
  punchlineEl.textContent = punchline || '';
  copyBtn.disabled = false;
  shareBtn.disabled = false;
}

function showError(message) {
  loadingEl.style.display = 'none';
  errorEl.hidden = false;
  errorEl.textContent = message;
  copyBtn.disabled = true;
  shareBtn.disabled = true;
  setupEl.textContent = '';
  punchlineEl.textContent = '';
}

// Primary fetch flow with fallback
async function loadJoke() {
  setLoading(true);
  try {
    const data = await fetchFromOfficial();
    // Official joke API returns setup + punchline
    displayJoke(data.setup, data.punchline);
  } catch (e1) {
    // fallback to icanhazdadjoke (single-line joke)
    try {
      const alt = await fetchFromIcanhaz();
      displayJoke(alt.joke, '');
    } catch (e2) {
      console.error('Both APIs failed', e1, e2);
      showError('Could not load a joke. Check your network and try again.');
    }
  }
}

newJokeBtn.addEventListener('click', () => {
  loadJoke();
});

// Copy current joke to clipboard
copyBtn.addEventListener('click', async () => {
  const text = [setupEl.textContent, punchlineEl.textContent].filter(Boolean).join(' — ');
  try {
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = 'Copied!';
    setTimeout(() => copyBtn.textContent = 'Copy', 1500);
  } catch (err) {
    copyBtn.textContent = 'Copy failed';
    setTimeout(() => copyBtn.textContent = 'Copy', 1500);
  }
});

// Share via native share API or fallback to copy
shareBtn.addEventListener('click', async () => {
  const text = [setupEl.textContent, punchlineEl.textContent].filter(Boolean).join(' — ');
  if (navigator.share) {
    try {
      await navigator.share({ title: 'Joke', text });
    } catch (err) {
      // user cancelled or share failed
    }
  } else {
    // Fallback: copy to clipboard and notify
    try {
      await navigator.clipboard.writeText(text);
      shareBtn.textContent = 'Copied to clipboard';
      setTimeout(() => shareBtn.textContent = 'Share', 1500);
    } catch (err) {
      shareBtn.textContent = 'Share failed';
      setTimeout(() => shareBtn.textContent = 'Share', 1500);
    }
  }
});

// Load a joke on first open
window.addEventListener('load', () => loadJoke());